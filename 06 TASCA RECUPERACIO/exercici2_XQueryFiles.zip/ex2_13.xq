let $ids := ("AL045", "AL046")
return collection("FACULTY_BD")//enrollment[@idStudent = $ids]/@idSubject