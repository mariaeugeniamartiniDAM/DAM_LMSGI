let $student_ids := collection("FACULTY_BD")//student[identity/surname1 = "Cooper" or identity/surname1 = "Flores"]/@idStudent
for $e in collection("FACULTY_BD")//enrollment[@idStudent = $student_ids and grade != 'NULL']
order by xs:double($e/grade) descending
return $e/grade