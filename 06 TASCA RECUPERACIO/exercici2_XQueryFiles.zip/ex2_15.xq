let $prof_ids := collection("FACULTY_BD")//professor[identity/surname1 = "Smith"]/@idProfessor
return collection("FACULTY_BD")//teach[idProfessor = $prof_ids]/idSubject/text()