let $students := db:get("FACULTY_BD")//student
let $matching := for $s in $students
  where db:get("FACULTY_BD")//enrollment[@idStudent = $s/@idStudent and grade castable as xs:double and xs:double(grade) > 9]
  return $s
return count($matching)