for $p in db:get("FACULTY_BD")//professor[address/province = "CA"]
order by $p/@idProfessor
return concat(
  "Nom:", $p/identity/name, " ", $p/identity/surname1, " ", $p/identity/surname2, 
  ", Id professor:", $p/@idProfessor, 
  ", Ciutat:", $p/address/municipality
)