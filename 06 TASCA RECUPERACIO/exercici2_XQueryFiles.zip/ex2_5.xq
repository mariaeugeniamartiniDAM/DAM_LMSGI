let $avg := avg(db:get("FACULTY_BD")//subject/credits)
for $s in db:get("FACULTY_BD")//subject[credits > $avg]
order by $s/name
return data($s/name)