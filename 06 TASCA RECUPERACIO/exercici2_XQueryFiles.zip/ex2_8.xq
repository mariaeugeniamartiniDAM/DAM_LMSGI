for $e in collection("FACULTY_BD")//enrollment[grade castable as xs:double and xs:double(grade) > 6]
let $s := collection("FACULTY_BD")//student[@idStudent = $e/@idStudent and address/province = "CO"]
where exists($s)
order by xs:double($e/grade) descending
return concat(
  "Estudiant: ", $e/@idStudent, 
  ", Assignatura: ", $e/@idSubject, 
  ", Nota: ", $e/grade, 
  ", Nom: ", $s/identity/name, " ", $s/identity/surname1, " ", $s/identity/surname2
)