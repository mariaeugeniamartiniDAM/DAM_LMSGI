let $nl := "&#10;"
let $num_estudiants := count(collection("FACULTY_BD")//student)
let $num_professors := count(collection("FACULTY_BD")//professor)
let $num_matricules := count(collection("FACULTY_BD")//enrollment)
return concat(
  "Número d'estudiants: ", $num_estudiants, $nl,
  "Número de professors: ", $num_professors, $nl,
  "Número de matrícules: ", $num_matricules
)