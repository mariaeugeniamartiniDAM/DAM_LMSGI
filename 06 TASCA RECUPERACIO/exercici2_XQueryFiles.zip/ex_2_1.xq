for $e in db:get("FACULTY_BD")//student
let $id := $e/@idStudent
where db:get("FACULTY_BD")//enrollment[@idStudent = $id and grade >= 4.2 and grade <= 4.3 and grade != 'NULL']
return data($e/identity/name)
